//
//  GunBeatGameApp.swift
//  GunBeatGame
//
//  Created by stud on 14/10/2025.
//

import SwiftUI

@main
struct GunBeatGameApp: App {
    var body: some Scene {
        WindowGroup {
            GameView()
        }
    }
}
