//
//  GunBeatGameTests.swift
//  GunBeatGameTests
//
//  Created by stud on 14/10/2025.
//

import Testing
@testable import GunBeatGame

struct GunBeatGameTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
